import{default as t}from"../components/pages/_page.svelte-ff9f6e56.js";export{t as component};
