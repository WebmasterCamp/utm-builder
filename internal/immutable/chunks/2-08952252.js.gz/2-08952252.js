import{default as t}from"../components/pages/_page.svelte-d18472fa.js";export{t as component};
